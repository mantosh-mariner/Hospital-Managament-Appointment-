package AllLogin;

import java.io.IOException;
import java.sql.Connection;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/adminlogin")
public class AdminLogin extends HttpServlet {

	All_connection obj = new All_connection();
	Connection connection = obj.getConnection();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String idString = req.getParameter("id");
		String passString = req.getParameter("pass");
		String c_passString = req.getParameter("c_pass");
		if (idString.equals("123Admin1") && passString.equals("Admin@123") && c_passString.equals("Admin@123")) {
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("/AddDoctor.jsp");
			requestDispatcher.forward(req, resp);
		} else {
			req.setAttribute("admin_error", "id and password mismatch");
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("/AdminLog1.jsp");
			requestDispatcher.forward(req, resp);
		}

	}
}
