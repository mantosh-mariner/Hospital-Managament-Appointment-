package AllLogin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/doctorlogin")
public class DoctorLogin extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		All_connection obj = new All_connection();
		Connection connection = obj.getConnection();

		String user_id = req.getParameter("user_id");
		String passString = req.getParameter("pass");
		String c_passString = req.getParameter("c_pass");

		try {
			if (!passString.equals(c_passString)) {
				req.setAttribute("notMatch", "Password not match");
				RequestDispatcher reqsDispatcher = req.getRequestDispatcher("/doctorlogin.jsp");
				reqsDispatcher.forward(req, resp);
				return;
			}

			PreparedStatement prst = connection
					.prepareStatement("select doctor_id FROM Doctor where userId_doctor=? and password=? ");
			prst.setString(1, user_id);
			prst.setString(2, passString);
			ResultSet resultSet = prst.executeQuery();
			if (resultSet.next()) {

				String doctor_id = resultSet.getString("doctor_id");
				req.getSession().setAttribute("doctor_id", doctor_id);
				List<Map<String, String>> booked = new ArrayList<>();

				try {
					PreparedStatement pstmt = connection.prepareStatement(
							"SELECT  booking_id, patient_name, appoint_date, p_phone, Patient_status  FROM appointment WHERE doctor_id=?");
					pstmt.setString(1, doctor_id);
					ResultSet rs = pstmt.executeQuery();

					while (rs.next()) {
						Map<String, String> booking = new HashMap<>();
						booking.put("booking_id", rs.getString("booking_id"));
						booking.put("patient_name", rs.getString("patient_name"));
						booking.put("appoint_date", rs.getString("appoint_date"));
						booking.put("p_phone", rs.getString("p_phone"));
						booking.put("Patient_status", rs.getString("Patient_status"));

						if (rs.getTimestamp("appoint_date") != null) {
							LocalDateTime appointmentDate = rs.getTimestamp("appoint_date").toLocalDateTime();
							LocalDateTime currentDateTime = LocalDateTime.now();
							long hoursDifference = ChronoUnit.HOURS.between(appointmentDate, currentDateTime);

							// Determine status based on the difference (expired if more than 24 hours)
							booking.put("status", hoursDifference > 24 ? "Expired" : "Active");
						} else {
							booking.put("status", "No appointment date available");
						}

						booked.add(booking);
					}

				} catch (SQLException e) {
					e.printStackTrace();
					req.setAttribute("error", "Unable to fetch appointment data: " + e.getMessage());
				}

				req.setAttribute("booked", booked);
				req.getSession().setAttribute("doctors_id", resultSet.getString("doctor_id"));
				RequestDispatcher resDispatcher = req.getRequestDispatcher("/WEB-INF/views/bookedlist.jsp");
				resDispatcher.forward(req, resp);
			} else {
				req.setAttribute("notMatch", "Sorry your record not found");
				RequestDispatcher reqsDispatcher = req.getRequestDispatcher("/doctorlogin.jsp");
				reqsDispatcher.forward(req, resp);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			req.setAttribute("notMatch", " Error to login" + e.getMessage());

			RequestDispatcher reqsDispatcher = req.getRequestDispatcher("/doctorlogin.jsp");
			reqsDispatcher.forward(req, resp);

		}

	}

}
