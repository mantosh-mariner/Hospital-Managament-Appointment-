package AllLogin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/patiectLog")
public class Patientlogin extends HttpServlet {

	All_connection objAll_connection = new All_connection();
	Connection connection = objAll_connection.getConnection();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String mail = req.getParameter("mail");
		String pass = req.getParameter("pass");

		try {
			PreparedStatement pStatement = connection.prepareStatement(
					"select patient_id, patient_name, email, phone_number from patient where email=? and password=?");
			pStatement.setString(1, mail);
			pStatement.setString(2, pass);

			ResultSet set = pStatement.executeQuery();

			if (set.next()) {
				String patientId = set.getString("patient_id");
				String nameString = set.getString("patient_name");
				String emailString = set.getString("email");
				String phoneString = set.getString("phone_number");
				req.getSession().setAttribute("patient_id", patientId);
				req.getSession().setAttribute("patient_name", nameString);
				req.getSession().setAttribute("email", emailString);
				req.getSession().setAttribute("phone_number", phoneString);
				RequestDispatcher dispatcher = req.getRequestDispatcher("/patient.jsp");
				dispatcher.forward(req, resp);
			} else {
				req.setAttribute("warning", "You have to first register.");
				RequestDispatcher dispatcher = req.getRequestDispatcher("/PatientLogs.jsp");
				dispatcher.forward(req, resp);
			}

		} catch (SQLException e) {
			req.setAttribute("warning", e.getMessage());
			RequestDispatcher dispatcher = req.getRequestDispatcher("/PatientLogs.jsp");
			dispatcher.forward(req, resp);
			e.printStackTrace();
		}
	}
}
