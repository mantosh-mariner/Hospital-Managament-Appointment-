package bookingdetailsfetch;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/allappointment")
public class allappointment extends HttpServlet {
	All_connection obj = new All_connection();
	Connection connection = obj.getConnection();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String patient_id = req.getParameter("patient_id"); // Ensure parameter matches
		List<Map<String, String>> booked = new ArrayList<>();

		try {
			PreparedStatement pstmt = connection.prepareStatement(
					"SELECT  booking_id, patient_name, appoint_date FROM appointment WHERE patient_id=?");
			pstmt.setString(1, patient_id);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Map<String, String> booking = new HashMap<>();
				booking.put("booking_id", rs.getString("booking_id"));
				booking.put("patient_name", rs.getString("patient_name"));
				booking.put("appoint_date", rs.getString("appoint_date"));

				if (rs.getTimestamp("appoint_date") != null) {
					LocalDateTime appointmentDate = rs.getTimestamp("appoint_date").toLocalDateTime();
					LocalDateTime currentDateTime = LocalDateTime.now();
					long hoursDifference = ChronoUnit.HOURS.between(appointmentDate, currentDateTime);

					// Determine status based on the difference (expired if more than 24 hours)
					booking.put("status", hoursDifference > 24 ? "Expired" : "Active");
				} else {
					booking.put("status", "No appointment date available");
				}

				booked.add(booking);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("error", "Unable to fetch appointment data: " + e.getMessage());
		}

		req.setAttribute("booked", booked);
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/allappointment.jsp");
		dispatcher.forward(req, resp);
	}
}
