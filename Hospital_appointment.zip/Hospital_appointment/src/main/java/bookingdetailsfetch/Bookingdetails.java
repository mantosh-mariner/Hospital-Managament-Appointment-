package bookingdetailsfetch;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/contrat")
public class Bookingdetails extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String doctor_id = req.getParameter("doctorId");
		String patient_id = req.getParameter("patientid");

		List<Map<String, String>> booked = new ArrayList<>();
		All_connection obj = new All_connection();

		try (Connection conn = obj.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(
						"SELECT d.room_No AS room, d.doctor_name AS name, p.booking_id AS book_id, p.appoint_date AS date "
								+ "FROM appointment p " + "JOIN Doctor d ON p.doctor_id = d.doctor_id "
								+ "WHERE p.patient_id = ? AND d.doctor_id = ? ORDER BY book_id DESC LIMIT 1")) {

			pstmt.setString(1, patient_id);
			pstmt.setString(2, doctor_id);

			try (ResultSet rs = pstmt.executeQuery()) {
				while (rs.next()) {
					Map<String, String> doctor = new HashMap<>();
					doctor.put("name", rs.getString("name"));
					doctor.put("room", rs.getString("room"));
					doctor.put("book_id", rs.getString("book_id"));

					if (rs.getString("date") != null) {
						LocalDateTime appointmentDate = rs.getTimestamp("date").toLocalDateTime();
						LocalDateTime currentDateTime = LocalDateTime.now();

						long hoursDifference = ChronoUnit.HOURS.between(appointmentDate, currentDateTime);

						// Determine status based on the difference (expired if more than 24 hours)
						if (hoursDifference > 24) {
							doctor.put("status", "Expired");
						} else {
							doctor.put("status", "Active");
						}
					} else {
						doctor.put("status", "No appointment date available");
					}

					booked.add(doctor);
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("error", "Unable to fetch doctor data: " + e.getMessage());
		}

		req.setAttribute("booked", booked);
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/contrat.jsp");
		dispatcher.forward(req, resp);
	}
}
