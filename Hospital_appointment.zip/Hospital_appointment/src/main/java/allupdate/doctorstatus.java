package allupdate;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import AllLogin.DoctorLogin;
import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/doctorstatus")
public class doctorstatus extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// Database connection object
	All_connection obj = new All_connection();
	Connection connection = obj.getConnection();
	DoctorLogin doctorLogin = new DoctorLogin();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String doctor_id = req.getParameter("doctor_id");
		String statuString = req.getParameter("status");

		PreparedStatement prstament = null;
		try {
			// Updating the patient status
			prstament = connection.prepareStatement("UPDATE Doctor SET availability=? WHERE doctor_id=?");
			prstament.setString(1, statuString);
			prstament.setString(2, doctor_id);

			int count = prstament.executeUpdate();

			if (count > 0) {

				// Forwarding to the JSP page to show updated appointments
				RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/bookedlist.jsp");
				dispatcher.forward(req, resp);

			} else {
				// If no rows were updated, show an error message
				req.setAttribute("error", "Failed to update appointment status. Please try again.");
				RequestDispatcher dispatcher = req
						.getRequestDispatcher("http://localhost:8080/Hospital_appointment/doctorlogin.jsp");
				dispatcher.forward(req, resp);
			}

		} catch (SQLException e) {
			// Handle any SQL exceptions
			req.setAttribute("error", "SQL Error: " + e.getMessage());
			RequestDispatcher dispatcher = req.getRequestDispatcher("/bookedlist.jsp");
			dispatcher.forward(req, resp);
			e.printStackTrace();
		}
	}
}
