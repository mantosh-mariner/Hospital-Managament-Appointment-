package allupdate;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/udate")
public class doctorupdate extends HttpServlet {

	All_connection obj = new All_connection();
	Connection connection = obj.getConnection();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		String nameString = req.getParameter("name");
		String specString = req.getParameter("spec");
		String phoneString = req.getParameter("phone");
		String user_idString = req.getParameter("user_id");
		String passString = req.getParameter("pass");
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"update  Doctor set userId_doctor=?, doctor_name=?, password=?,specialization=?, phone_number=?  WHERE doctor_id = ?");

			preparedStatement.setString(1, user_idString);
			preparedStatement.setString(2, nameString);
			preparedStatement.setString(3, passString);
			preparedStatement.setString(4, specString);
			preparedStatement.setString(5, phoneString);
			preparedStatement.setString(6, id);

			int count = preparedStatement.executeUpdate();
			if (count > 0) {
				req.setAttribute("succ", "Doctor deleted successfully.");
			} else {
				req.setAttribute("succ", "Doctor not found or already deleted.");
			}
			req.setAttribute("succ", "Doctor deleted successfully.");
			resp.sendRedirect("http://localhost:8080/Hospital_appointment/doctorList");

		} catch (SQLException e) {
			req.setAttribute("succ", "Error: " + e.getMessage());
			e.printStackTrace();
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("/doctorList");
			requestDispatcher.forward(req, resp);
		}
	}
}
