package allupdate;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import AllLogin.DoctorLogin;
import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/updatestatus")
public class updatestatus extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// Database connection object
	All_connection obj = new All_connection();
	Connection connection = obj.getConnection();
	DoctorLogin doctorLogin = new DoctorLogin();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String updated_data = req.getParameter("updata");
		String booking_id = req.getParameter("booking_id");
		String doctor_id = req.getParameter("doctor_id");

		PreparedStatement prstament = null;
		try {
			// Updating the patient status
			prstament = connection.prepareStatement("UPDATE appointment SET Patient_status=? WHERE booking_id=?");
			prstament.setString(1, updated_data);
			prstament.setString(2, booking_id);

			int count = prstament.executeUpdate();
			List<Map<String, String>> doctorLists = new ArrayList<>();

			if (count > 0) {
				try {
					// Fetching updated appointments for the doctor
					PreparedStatement pstmt = connection
							.prepareStatement("SELECT booking_id, patient_name, appoint_date, p_phone, Patient_status "
									+ "FROM appointment WHERE doctor_id=?");
					pstmt.setString(1, doctor_id);
					ResultSet rs = pstmt.executeQuery();

					while (rs.next()) {
						Map<String, String> booking = new HashMap<>();
						booking.put("booking_id", rs.getString("booking_id"));
						booking.put("patient_name", rs.getString("patient_name"));
						booking.put("appoint_date", rs.getString("appoint_date"));
						booking.put("p_phone", rs.getString("p_phone"));
						booking.put("Patient_status", rs.getString("Patient_status"));

						// Check if appointment date is valid and calculate time difference
						if (rs.getTimestamp("appoint_date") != null) {
							LocalDateTime appointmentDate = rs.getTimestamp("appoint_date").toLocalDateTime();
							LocalDateTime currentDateTime = LocalDateTime.now();
							long hoursDifference = ChronoUnit.HOURS.between(appointmentDate, currentDateTime);

							// Determine if the appointment is expired
							booking.put("status", hoursDifference > 24 ? "Expired" : "Active");
						} else {
							booking.put("status", "No appointment date available");
						}

						doctorLists.add(booking);
					}

					req.setAttribute("booked", doctorLists);
					req.setAttribute("success", "Appointment status updated successfully!");

				} catch (SQLException e) {
					e.printStackTrace();
					req.setAttribute("error", "Unable to fetch updated appointment data: " + e.getMessage());
				}

				// Forwarding to the JSP page to show updated appointments
				RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/bookedlist.jsp");
				dispatcher.forward(req, resp);

			} else {
				// If no rows were updated, show an error message
				req.setAttribute("error", "Failed to update appointment status. Please try again.");
				RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/bookedlist.jsp");
				dispatcher.forward(req, resp);
			}

		} catch (SQLException e) {
			// Handle any SQL exceptions
			req.setAttribute("error", "SQL Error: " + e.getMessage());
			RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/bookedlist.jsp");
			dispatcher.forward(req, resp);
			e.printStackTrace();
		}
	}
}
