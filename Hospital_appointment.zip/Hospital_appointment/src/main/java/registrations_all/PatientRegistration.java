package registrations_all;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/patientregistration")
public class PatientRegistration extends HttpServlet {
	All_connection objAll_connection = new All_connection();
	Connection connection = objAll_connection.getConnection();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter outPrintWriter = resp.getWriter();
		String nameString = req.getParameter("patinetName");
		String mailString = req.getParameter("patientMail");
		String phonString = req.getParameter("patientPhone");
		String passString = req.getParameter("patientPass");
		String dateString = req.getParameter("patientDate");
		String gendString = req.getParameter("patientGender");
		String addressString = req.getParameter("patientAddress");

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"insert into Patient (patient_name, email, phone_number, password, date_of_birth, gender, address) values(?,?,?,?,?,?,?)");
			preparedStatement.setString(1, nameString);
			preparedStatement.setString(2, mailString);
			preparedStatement.setString(3, phonString);
			preparedStatement.setString(4, passString);
			preparedStatement.setString(5, dateString);
			preparedStatement.setString(6, gendString);
			preparedStatement.setString(7, addressString);

			int count = preparedStatement.executeUpdate();
			if (count > 0) {
				RequestDispatcher resDispatcher = req.getRequestDispatcher("/PatientLogs.jsp");
				resDispatcher.forward(req, resp);
			} else {
				req.setAttribute("popupMessage", "you already exist:");
				RequestDispatcher resDispatcher = req.getRequestDispatcher("/PatientReg.jsp");
				resDispatcher.forward(req, resp);
			}
		} catch (SQLException e) {
			req.setAttribute("popupMessage", "User registration not successful: " + e.getMessage());
			RequestDispatcher resDispatcher = req.getRequestDispatcher("/PatientReg.jsp");
			resDispatcher.forward(req, resp);
			e.printStackTrace();
		}
	}
}
