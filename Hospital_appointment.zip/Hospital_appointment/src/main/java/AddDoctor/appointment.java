package AddDoctor;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/apointment")
public class appointment extends HttpServlet {

	All_connection obj = new All_connection();
	Connection connection = obj.getConnection();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String doctor_id = req.getParameter("doctorId");
		String patient_id = req.getParameter("patientid");
		String patient_name = req.getParameter("patient_name");
		String p_email = req.getParameter("email");
		String p_phone = req.getParameter("phonenumber");

		try {
			PreparedStatement pStatement = connection.prepareStatement(
					"INSERT INTO appointment(patient_name, patient_mail, patient_id, doctor_id, p_phone) VALUES (?, ?, ?, ?, ?)");

			pStatement.setString(1, patient_name);
			pStatement.setString(2, p_email);
			pStatement.setString(3, patient_id);
			pStatement.setString(4, doctor_id);
			pStatement.setString(5, p_phone);

			int count = pStatement.executeUpdate();
			if (count > 0) {
				req.getSession().setAttribute("doctor_id", doctor_id);
				req.setAttribute("pop", "Appointment added successfully");
				RequestDispatcher dispatcher = req.getRequestDispatcher("/success.jsp");
				dispatcher.forward(req, resp);
			} else {
				req.setAttribute("pop", "Not added");
				RequestDispatcher dispatcher = req.getRequestDispatcher("/success.jsp");
				dispatcher.forward(req, resp);
			}

		} catch (SQLException e) {
			req.setAttribute("pop", "Not added: " + e.getMessage());
			RequestDispatcher dispatcher = req.getRequestDispatcher("/success.jsp");
			dispatcher.forward(req, resp);
			e.printStackTrace();
		}
	}
}
