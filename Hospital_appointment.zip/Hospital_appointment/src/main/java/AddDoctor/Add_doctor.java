package AddDoctor;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/add_doctor")

public class Add_doctor extends HttpServlet {

	All_connection obj = new All_connection();
	Connection connection = obj.getConnection();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String name = req.getParameter("dname");
		String mailString = req.getParameter("dmail");
		String passString = req.getParameter("dpass");
		String sepString = req.getParameter("dspec");
		String phoneString = req.getParameter("dphone");
		String expString = req.getParameter("dexp");
		String doctor_id = req.getParameter("doctor_id");
		String rooomString = req.getParameter("room");

		try {
			PreparedStatement pStatement = connection.prepareStatement(
					"insert into Doctor(doctor_name, email, password, specialization, phone_number, experience, userId_doctor,room_No ) values(?,?,?,?,?,?,?,?)");

			pStatement.setString(1, name);
			pStatement.setString(2, mailString);

			pStatement.setString(3, passString);
			pStatement.setString(4, sepString);
			pStatement.setString(5, phoneString);
			pStatement.setString(6, expString);
			pStatement.setString(7, doctor_id);
			pStatement.setString(8, rooomString);
			int count = pStatement.executeUpdate();
			if (count > 0) {

				req.setAttribute("pop", "Added successfully");
				RequestDispatcher dispatcher = req.getRequestDispatcher("/AddDoctor.jsp");
				dispatcher.forward(req, resp);
			}

		} catch (SQLException e) {

			req.setAttribute("pop", "Not added " + e.getMessage());
			RequestDispatcher dispatcher = req.getRequestDispatcher("/AddDoctor.jsp");
			dispatcher.forward(req, resp);
			e.printStackTrace();
		}

	}

}
