package Coonnection;

import java.sql.Connection;
import java.sql.DriverManager;

public class All_connection {
	Connection con = null;

	public Connection getConnection() {
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/HospitalAppoint", "root", "Admin@123");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return con;

	}

//	public Connection getConnection() {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
