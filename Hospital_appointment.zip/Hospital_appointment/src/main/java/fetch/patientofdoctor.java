package fetch;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/patientlists")
public class patientofdoctor extends HttpServlet {
	All_connection obj = new All_connection();
	Connection connection = obj.getConnection();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		List<Map<String, String>> booked = new ArrayList<>();

		try {
			PreparedStatement pstmt = connection.prepareStatement(
					"SELECT  booking_id, patient_name,patient_mail, patient_id,doctor_id,p_phone, appoint_date FROM appointment ");

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Map<String, String> booking = new HashMap<>();
				booking.put("booking_id", rs.getString("booking_id"));
				booking.put("patient_name", rs.getString("patient_name"));
				booking.put("patient_mail", rs.getString("patient_mail"));
				booking.put("patient_id", rs.getString("patient_id"));
				booking.put("doctor_id", rs.getString("doctor_id"));
				booking.put("p_phone", rs.getString("p_phone"));
				booking.put("appoint_date", rs.getString("appoint_date"));

				if (rs.getTimestamp("appoint_date") != null) {
					LocalDateTime appointmentDate = rs.getTimestamp("appoint_date").toLocalDateTime();
					LocalDateTime currentDateTime = LocalDateTime.now();
					long hoursDifference = ChronoUnit.HOURS.between(appointmentDate, currentDateTime);

					// Determine status based on the difference (expired if more than 24 hours)
					booking.put("status", hoursDifference > 24 ? "Expired" : "Active");
				} else {
					booking.put("status", "No appointment date available");
				}

				booked.add(booking);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("error", "Unable to fetch appointment data: " + e.getMessage());
		}

		req.setAttribute("booked", booked);
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/listofpatient.jsp");
		dispatcher.forward(req, resp);
	}
}
