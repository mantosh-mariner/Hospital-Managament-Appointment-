package fetch;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Coonnection.All_connection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/doctorList") // URL pattern to access this servlet
public class fetchDoctor extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Map<String, String>> doctorList = new ArrayList<>();
		All_connection obj = new All_connection();

		try (Connection conn = obj.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(
						"SELECT doctor_id, doctor_name, specialization, password, userId_doctor,  phone_number, availability FROM Doctor");
				ResultSet rs = pstmt.executeQuery()) {

			while (rs.next()) {
				Map<String, String> doctor = new HashMap<>();
				doctor.put("id", rs.getString("doctor_id"));
				doctor.put("name", rs.getString("doctor_name"));
				doctor.put("specialization", rs.getString("specialization"));
				doctor.put("password", rs.getString("password"));
				doctor.put("userId_doctor", rs.getString("userId_doctor"));
				doctor.put("phone_number", rs.getString("phone_number"));
				doctor.put("availability", rs.getString("availability"));
				doctorList.add(doctor);
			}
		} catch (SQLException e) {

			e.printStackTrace();
			request.setAttribute("error", "Unable to fetch doctor data: " + e.getMessage());
		}

		request.setAttribute("doctorList", doctorList);

		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/doctorList.jsp");
		dispatcher.forward(request, response);
	}
}
